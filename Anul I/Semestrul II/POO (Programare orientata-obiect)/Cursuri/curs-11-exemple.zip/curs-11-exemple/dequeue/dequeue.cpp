#include <iostream>
#include <vector>

using namespace std;

class Dequeue {
 public:
  virtual void pushBack(int) = 0;
  virtual void pushFront(int) = 0;
  virtual int topBack() = 0;
  virtual int topFront() = 0;
  virtual void popBack() = 0;
  virtual void popFront() = 0;
};

class Vec2DeqAdapter : public Dequeue {
 public:
  Vec2DeqAdapter() {vec = new vector<int>;}
  void pushBack(int x) {vec->push_back(x);}
  void pushFront(int x) {vec->insert(vec->begin(), x);}
  int topBack() {return vec->back();}
  int topFront() {return vec->front();}
  void popBack() {vec->pop_back();}
  void popFront(){vec->erase(vec->begin());}
 private: 
  vector<int> *vec;
};


int main() {
  Dequeue *deq = new Vec2DeqAdapter;
  deq->pushBack(2);
  deq->pushFront(5);
  cout << deq->topFront() << ", " << deq->topBack() << endl;
  return 0;
}
