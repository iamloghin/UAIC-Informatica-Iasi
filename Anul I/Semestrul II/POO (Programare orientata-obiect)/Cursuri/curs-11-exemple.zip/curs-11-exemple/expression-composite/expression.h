#include<list>
#include<algorithm>

using namespace std;

class Expression
{
public:
	virtual int getVal() = 0;
	virtual void add(Expression* exp) = 0;
	virtual void remove() = 0;
	virtual Expression* getCompoundExpression() { return NULL;}
};


class Constant : public Expression
{
public:
	Constant(int x = 0) { val = x; }
	int getVal() { return  val;}
	void add(Expression*) {}
	void remove() {}
private:
	int val;
};

class CompoundExpression : public Expression
{
public:
	void add(Expression* exp) { members.push_back(exp); }
	void remove() { members.pop_back(); }
	Expression* getCompoundExpression() { return this; }
protected:
	list<Expression*> members;
};

class ProdExpression : public CompoundExpression
{
public:
	ProdExpression() {}
	int getVal()
	{
		list<Expression*>::iterator i;
		int valTemp = 1;
		for ( i = members.begin(); i != members.end(); ++i)
			valTemp *= (*i)->getVal();
		return valTemp;
	}
};

class SumExpression : public CompoundExpression
{
public:
	SumExpression() {}
	int getVal()
	{
		list<Expression*>::iterator i;
		int valTemp = 0;
		for ( i = members.begin(); i != members.end(); ++i)
			valTemp += (*i)->getVal();
		return valTemp;
	}
};
	