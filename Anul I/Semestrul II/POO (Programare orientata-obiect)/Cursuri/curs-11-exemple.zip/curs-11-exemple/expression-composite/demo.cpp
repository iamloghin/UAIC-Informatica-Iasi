#include "expression.h"
#include <iostream>

int main()
{
	Constant* one = new Constant(1);
	Constant* two = new Constant(2);
	ProdExpression* e1 =  new ProdExpression();
	e1->add(one);
	e1->add(two);
	e1->remove();
	one->remove();
	cout << e1->getVal() << endl;
	SumExpression* e2 = new SumExpression();
	e2->add(e1);
	e2->add(two);
	cout << e2->getVal() << endl;
	return 0;
}