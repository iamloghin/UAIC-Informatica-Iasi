#include <iostream>
#include <exception>
#include <cstdlib>

using namespace std;

// exceptii: functia terminate()

class Unu : exception { };
class Doi : exception { };
class Trei : exception { };
class Patru : exception { };

void unu()
{
	throw Unu();
}

void doi()
{
	throw Doi();
}

void trei()
{
	throw Trei();
}

void patru()
{
	throw Patru();
}

void my_terminate() {
  cout << "Revin in 5 min!" << endl;
  abort();
}

void (*old_terminate)()
  = set_terminate(my_terminate);


int main()
{
	try {
		try	{
			try	{
				// unu();
				// doi();
				 trei();
				// patru();
			} catch (Trei) {
				cout << "Exceptie Trei.\n";
			}
		} catch (Doi) {
			cout << "Exceptie Doi.\n";
		}
	} catch(Unu) {
		cout << "Exceptie Unu.\n";
	}
	return 0;
}
