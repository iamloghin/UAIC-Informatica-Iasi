#include <iostream>
using namespace std;


#define MAX_STACK 5

template <class T>
class Stack
{
public:
  Stack();
  ~Stack();
  void push(T);
  void pop();
  T top();
  bool isEmpty(); 
private:
  T elt[MAX_STACK];
  int topIndex;
};

template <class T>
Stack<T>::Stack() {
  topIndex = 0;
}

template <class T>
Stack<T>::~Stack() {}

template <class T>
void Stack<T>::push(T x) 
{
  if (topIndex == MAX_STACK)
    throw "Class Stack overflow.";
  elt[topIndex++] = x;
}

template <class T>
T Stack<T>::top()
{
  if (topIndex <= 0) 
    throw "Try reading from an empty stack.";
  return elt[topIndex-1];
}


