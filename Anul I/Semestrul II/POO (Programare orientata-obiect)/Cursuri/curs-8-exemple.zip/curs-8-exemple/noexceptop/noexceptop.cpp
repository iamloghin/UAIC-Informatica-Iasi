#include <iostream>

class A {
public:
  A() noexcept(false) {
    throw 2;
  }
};

class B {
public:
  B() noexcept(true) {  }
};

class C {
public:
  C() noexcept(true) {}
  // C(const C&) {}
  ~C() noexcept(false) {}
};

template <typename T>
void f() {
  if (noexcept(T()))
    std::cout << "NO Exception in Constructor" << std::endl;
  else 
    std::cout << "Exception in Constructor" << std::endl;
}

template <typename T>
void g() {
  if (noexcept(T(std::declval<T>())))
    std::cout << "NO Exception in Any Constructor or Destructor" << std::endl;
  else 
    std::cout << "Possible Exception in a Constructor  or Destructor" << std::endl;
}
    
int main() {
  //  f<A>();
  //  f<B>();
  g<C>();
}

