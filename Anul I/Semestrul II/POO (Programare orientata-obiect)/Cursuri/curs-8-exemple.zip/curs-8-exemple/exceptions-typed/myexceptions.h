#ifndef MYEXCEPTIONS_H
#define MYEXCEPTIONS_H 

template <class T>
class Stack;

template <class T>
class StackOverflowException {
 public:
  StackOverflowException(Stack<T>);
  void debugPrint();
 private:
  Stack<T> stackErr;
};

template <class T>
class StackEmptyException {
 public:
  void debugPrint();
};

class DivByZeroException {
 public:
  DivByZeroException(int);
  void debugPrint();
 private:
  int divident;
};


template <class T>
StackOverflowException<T>::StackOverflowException(Stack<T> astack) 
{
  stackErr = astack;
}

template <class T>
void StackOverflowException<T>::debugPrint() 
{
  Stack<T> stCopy = stackErr;
  std::cout << "Stack Overflow exception." << std::endl;
  while ( ! stCopy.isEmpty() ) {
    std::cout << stCopy.top() << std::endl;
    stCopy.pop();
  }
}


template <class T>
void StackEmptyException<T>::debugPrint() 
{
  std::cout << "Empty stack exception." << std::endl;
}

DivByZeroException::DivByZeroException(int x)
{
  divident = x;
}

void DivByZeroException::debugPrint()
{
  std::cout << "Division by zero. " << divident << std::endl;
}


#endif
