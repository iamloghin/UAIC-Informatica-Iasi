#include <iostream>
#include "stack.h"
#include "myexceptions.h"
using namespace std;

int safeDiv(int divident, int divisor)
{
  if (divisor == 0) 
    throw DivByZeroException(divident);
  return divident / divisor;
}

void unknown()
{
  throw rand();
}

int main() {
  int option, i;
  char c = 'a';
  Stack<char> st; 
  cout << "Option: ";
  cin >> option;
  try {
    switch (option) {
      case 1: 
        for (i = 0; i <= 9; ++i) st.push(c++);
      case 2:
        for (i = 0; i <= 9; ++i) st.pop();
      case 3:
        safeDiv(3, 0);
      case 4:
        unknown();
      default:
	cout << "Execution without exceptions." << endl;
    }
  }
  catch(StackOverflowException<char> excpt) {
    excpt.debugPrint();
  }
  catch(StackEmptyException<char> excpt) {
    excpt.debugPrint();
  }
  catch(DivByZeroException excpt) {
    excpt.debugPrint();
  }
  catch(...) {
    cout << "Unknown exception." << endl;
  }
  return 0;
}

