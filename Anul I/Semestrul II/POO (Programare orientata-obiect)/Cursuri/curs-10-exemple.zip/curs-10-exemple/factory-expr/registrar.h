#ifndef REGISTRAR_H
#define REGISTRAR_H

#include "expression.h"
#include <map>
#include <string>

using namespace std;

typedef Expression* ( * CreateExprFn )();

class Registrar
{
public:
	Registrar() {}
	bool registerExpr(string tag, CreateExprFn createExprFn )
	{
	  return catalog.insert( std::pair<string, CreateExprFn>(tag, createExprFn) ).second;
	}

    void unregisterExpr(string tag)
	{
		catalog.erase(tag);
	}

    Expression* createExpr(string tag)
	{
		map<string, CreateExprFn>::iterator i;
		i = catalog.find(tag);
		if ( i == catalog.end() )
			throw string( "Unknown expression tag " + tag );
		return (i->second)();
	}
protected:
    map<string, CreateExprFn> catalog;
};

#endif


