#include "expr-manager.h"
#include "visitor-storef.h"
#include <iostream>

using namespace std;

string VisitorStoref::indent("");

Expression* createConstant() {
	return new Constant();
}


Expression* createVariable() {
	return new Variable();
}

Expression* createProd() {
	return new ProdExpression();
}


Expression* createSum() {
	return new SumExpression();
}


int main()
{
	Constant* one = new Constant(1);
	Constant* two = new Constant(2);
	Variable *a = new Variable("a");
	Variable *b = new Variable("b");

	ProdExpression* e1 =  new ProdExpression();
	e1->add(one);
	e1->add(a);
	SumExpression* e2 = new SumExpression();
	e2->add(e1);
	e2->add(two);
	e2->add(b);

	ofstream outfile("test.xml");
	VisitorStoref visitorStoref;
	e2->accept(visitorStoref, outfile);
	outfile.close();

	Registrar aReg;
	aReg.registerExpr("<constant>", createConstant);
	aReg.registerExpr("<variable>", createVariable);
	aReg.registerExpr("<prod>", createProd);
	aReg.registerExpr("<sum>", createSum);



	outfile.open("test-copy.xml", ios::out);
	ifstream inpfile("test.xml");

	try {
    	Expression* exprCopy = ExprManager::loadf(inpfile, aReg);
		e2->accept(visitorStoref, outfile);
	}
	catch(string msg) {
		cout << msg << endl;
	}
	inpfile.close();

	return 0;
}