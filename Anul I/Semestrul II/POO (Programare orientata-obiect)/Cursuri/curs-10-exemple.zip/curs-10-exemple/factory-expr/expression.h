#ifndef EXPRESSION_H
#define EXPRESSION_H

#include <list>
#include <string>
#include <algorithm>
#include <fstream>
#include "visitor.h"
//#include <iostream>

using namespace std;

class Expression
{
public:
	virtual void add(Expression* exp) = 0;
	virtual void remove() = 0;
	virtual Expression* getCompoundExpression() { return NULL;}
	virtual void loadInfo(ifstream&) {}
	virtual void accept(Visitor&, ofstream&) {}
};


class Constant : public Expression
{
public:
	Constant(int x = 0) { val = x; }
	int getVal() {return val;}
	void add(Expression*) {}
	void remove() {}
	void loadInfo(ifstream& f) {
		f >> val;
	}
	void accept(Visitor& visitor, ofstream& f) {
		visitor.visitConstant(this, f);
	}
private:
	int val;
};

class Variable : public Expression {
public:
	Variable(string var = "") {name = var;}
	string getName() {return name;}
	void add(Expression*) {}
	void remove() {}
	void loadInfo(ifstream& f) {
		f >> name;
	}
	void accept(Visitor& visitor, ofstream& f) {
		visitor.visitVariable(this, f);
	}
private:
	string name;
};


class CompoundExpression : public Expression
{
public:
	void add(Expression* exp) { members.push_back(exp); }
	void remove() { members.pop_back(); }
	Expression* getCompoundExpression() { return this; }
	void accept(Visitor& visitor, ofstream& f) {
		list<Expression*>::iterator it;
		for ( it = members.begin(); it != members.end(); ++it)
			(*it)->accept(visitor, f);
	}
protected:
	list<Expression*> members;
};

class ProdExpression : public CompoundExpression
{
public:
	ProdExpression() {}

	void accept(Visitor& visitor, ofstream& f) {
		visitor.visitProdExpression(this, f);
	}
};


class SumExpression : public CompoundExpression
{
public:
	SumExpression() {}
	
	void accept(Visitor& visitor, ofstream& f) {
		visitor.visitSumExpression(this, f);
	}
};

#endif
