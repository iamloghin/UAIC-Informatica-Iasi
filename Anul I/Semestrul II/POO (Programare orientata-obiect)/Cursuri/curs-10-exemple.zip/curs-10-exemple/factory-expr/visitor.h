#ifndef VISITOR_H
#define VISITOR_H

using namespace std;

class Constant;
class Variable;
class CompoundExpression;
class ProdExpression;
class SumExpression;

class Visitor {
public:
	virtual void visitConstant(Constant*, ofstream& f) = 0;
	virtual void visitVariable(Variable*, ofstream& f) = 0;
	virtual void visitCompoundExpression(CompoundExpression*, ofstream& f) {}
	virtual void visitProdExpression(ProdExpression*, ofstream& f) {}
	virtual void visitSumExpression(SumExpression*, ofstream& f) {}
protected:
	Visitor(){};
};


#endif
