#ifndef VISITOR_STOREF_H
#define VISITOR_STOREF_H
#include "expression.h"

class VisitorStoref : public Visitor {
public:
	static string indent;
	void visitConstant(Constant* constant, ofstream& f) {
		f << indent;
		f << "<constant> " << constant->getVal() <<" </constant>";
		f << endl;
	}
	
	void visitVariable(Variable* variable, ofstream& f) {
		f << indent;
		f << "<variable> " << variable->getName() <<" </variable>";
		f << endl;
	}

	void visitProdExpression(ProdExpression* prod, ofstream& f) {
		f << indent;
		f << "<prod>" << endl;
		indent += "  ";
		prod->CompoundExpression::accept(*this, f);
		indent = indent.erase(indent.size()-2,2);
		f << indent;
		f << "</prod>" << endl;
	}

	void visitSumExpression(SumExpression* sum, ofstream& f) {
		f << indent.c_str();
		f << "<sum>" << endl;
		indent += "  ";
		sum->CompoundExpression::accept(*this, f);
		indent = indent.erase(indent.size()-2,2);
		f << indent;
		f << "</sum>" << endl;
	}
};
#endif
