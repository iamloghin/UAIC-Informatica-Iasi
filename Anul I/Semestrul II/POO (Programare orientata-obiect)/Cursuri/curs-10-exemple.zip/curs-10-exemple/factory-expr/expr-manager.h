#ifndef EXPR_MANAGER_H
#define EXPR_MANAGER_H

#include "registrar.h"

class ExprManager {
public:
	static 	Expression* loadf(ifstream& f, Registrar& reg) {
		if (f.eof())
			throw "Unknown file.";
		string tag;
		f >> tag;
		return loadfRec(f, reg, tag);
	}

	static Expression* loadfRec(ifstream& f, Registrar& reg, string tag) {
		Expression* expr1 = reg.createExpr(tag);
		string endTag = tag.insert(1,"/");
		Expression* expr2;
		if (expr1->getCompoundExpression()) {
			if (f.eof())
				throw "File illformatted.";
		    string nextTag;
			f >> nextTag;
			while (endTag != nextTag && !f.eof()) {
				expr2 = loadfRec(f, reg, nextTag);
				expr1->add(expr2);
				f >> nextTag;
			}
		}
		else { 
			if (f.eof())
				throw "File illformatted.";
			expr1->loadInfo(f);
			if (f.eof())
				throw "File illformatted.";
			f >> tag;
		}
		return expr1;
	}
};

#endif
