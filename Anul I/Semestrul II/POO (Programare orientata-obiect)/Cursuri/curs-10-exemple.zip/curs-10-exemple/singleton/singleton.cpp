#include <iostream>
using namespace std;

template <typename Data>
class Singleton {
public:
  static Singleton<Data>& instance() {
    return uniqueInstance;
  }
  // methode care opereaza peste instanta unica
  Data getData() { return data; }
  void setData(Data x) { data = x; }
protected:
  Data data;		// campurile care descriu starea instantei
  Singleton() { }               //constructor
  void operator=(Singleton&);	// operator de atribuire
  Singleton(const Singleton&);  // constructor de copiere
  Singleton(Singleton&);        // constructor de copiere
private:
  static Singleton<Data> uniqueInstance;  // instanta unica
};

template <typename Data>
Singleton<Data> Singleton<Data>::uniqueInstance;

int main() {
  Singleton<int> &s1 = Singleton<int>::instance();
  cout << s1.getData() << endl;
  Singleton<int> &s2 = Singleton<int>::instance();
  s2.setData(9);
  cout << s1.getData() << endl;
  Singleton<int> &s3 = s2;
  cout << s3.getData() << endl;
  // urmatoarele 4 instructiuni se compileaza numai daca se comenteaza constructorul de copiere
  /*
  Singleton<int> s4 = s2;
  s4.setData(23);
  cout << s4.getData() << endl;
  cout << s2.getData() << endl;
  */
  // urmatoarea instructiune se compileaza numai daca se comenteaza si operatorul de atribuire
  /*
  s3 = s2;
  s3.setData(43);
  cout << s1.getData() << endl;  // 43
  cout << s2.getData() << endl;  // 43
  */
  return 0;
}
