#include <iostream>
using namespace std;

template <typename Data>
class Singleton {
public:
  static Singleton* instance() {
    if (uniqueInstance == 0) { 
		uniqueInstance = new Singleton();
	}
    return uniqueInstance;
  }
  // metode care opereaza peste instanta unica
  Data getData() { return data; }
  void setData(Data x) { data = x; }
protected:
  Data data;		// campurile care descriu starea instantei
  Singleton()  { }                   //constructor
  // void operator=(Singleton&);     // nu mai e necesar
  // Singleton(const Singleton&);    // nu mai e necesar
  // Singleton(Singleton&);          // nu mai e necesar
private:
  static Singleton<Data>* uniqueInstance;  // pointer la instanta unica
};

template <typename Data>
Singleton<Data>* Singleton<Data>::uniqueInstance = 0;

int main() {
  Singleton<int>* s1 = Singleton<int>::instance();
  s1->setData(47);
  cout << s1->getData() << endl;
  Singleton<int>* s2 = Singleton<int>::instance();
  s2->setData(9);
  cout << s1->getData() << endl;
  cout << s2->getData() << endl;
  // urmatoarele 4 instructiuni se executa in orice situatie
  Singleton<int>* s4 = s2;
  s4->setData(23);
  cout << s4->getData() << endl;
  cout << s2->getData() << endl;
  // urmatoarele 4 instructiuni se executa in orice situatie
  s4 = s1;
  s4->setData(43);
  cout << s4->getData() << endl;
  cout << s2->getData() << endl;

  // urmatoarea instructiune nu se compileaza daca se decomenteaza constructorul de copiere
  Singleton<int> s5 = (*s2);
  
  // urmatoarea instructiune nu se compileaza daca se decomenteaza si operatorul de atribuire
    s5 = *s1;


  return 0;
}
