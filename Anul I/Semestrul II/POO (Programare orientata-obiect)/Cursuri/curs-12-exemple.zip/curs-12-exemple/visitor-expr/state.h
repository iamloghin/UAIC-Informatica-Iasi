#ifndef STATE_H
#define STATE_H
#include <map>
#include <string>
#include <iostream>

using namespace std;

class State {
public:
	int lookup(string var) { return state[var]; }
	void update(string var, int val) {
		map<string, int>::iterator it;
		if ((it = state.find(var)) == state.end())
		{
			state.insert(pair<const string, const int>(var, val));
		}
		else state[var] = val;
	}
	void print() {
		map<string, int>::iterator it;
		for (it = state.begin(); it != state.end(); ++it)
			cout << (*it).first << " |-> " << (*it).second << endl;
	}
private:
	map<string, int> state;
};
#endif
