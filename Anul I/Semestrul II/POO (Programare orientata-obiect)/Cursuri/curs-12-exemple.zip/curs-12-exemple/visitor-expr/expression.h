#ifndef EXPRESSION_H
#define EXPRESSION_H

#include <list>
#include <string>
#include <algorithm>
#include "visitor.h"

using namespace std;

class Expression
{
public:
	virtual void add(Expression* exp) = 0;
	virtual void remove() = 0;
	virtual Expression* getCompoundExpression() { return NULL;}
	
	virtual void accept(Visitor& visitor) {}
};


class Constant : public Expression
{
public:
	Constant(int x = 0) { val = x; }
	int getVal() {return val;}
	void add(Expression*) {}
	void remove() {}
	
	void accept(Visitor& visitor) {
		visitor.visitConstant(this);
	}
private:
	int val;
};

class Variable : public Expression {
public:
	Variable(string var) {name = var;}
	string getName() {return name;}
	void add(Expression*) {}
	void remove() {}

	void accept(Visitor& visitor) {
		visitor.visitVariable(this);
	}
private:
	string name;
};

class CompoundExpression : public Expression
{
public:
	void add(Expression* exp) { members.push_back(exp); }
	void remove() { members.pop_back(); }
	int size() { return members.size(); }
	Expression* getCompoundExpression() { return this; }
	
	void accept(Visitor& visitor) {
		list<Expression*>::iterator it;
		for ( it = members.begin(); it != members.end(); ++it)
			(*it)->accept(visitor);
	}
protected:
	list<Expression*> members;
};

class ProdExpression : public CompoundExpression
{
public:
	ProdExpression() {}
	
	void accept(Visitor& visitor) {
		this->CompoundExpression::accept(visitor);
		visitor.visitProdExpression(this);
	}
};

class SumExpression : public CompoundExpression
{
public:
	SumExpression() {}
	
	void accept(Visitor& visitor) {
		this->CompoundExpression::accept(visitor);
		visitor.visitSumExpression(this);
	}
};
#endif
