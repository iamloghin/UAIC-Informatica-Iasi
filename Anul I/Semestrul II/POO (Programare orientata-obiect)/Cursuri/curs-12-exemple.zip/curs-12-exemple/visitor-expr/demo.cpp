#include "expression.h"
#include "state.h"
#include "visitor-print.h"
#include "visitor-eval.h"
#include <iostream>

int main()
{
	Constant* one = new Constant(1);
	Constant* two = new Constant(2);
	Variable *a = new Variable("a");
	Variable *b = new Variable("b");

	ProdExpression* e1 =  new ProdExpression();
	e1->add(two);
	e1->add(a);
	SumExpression* e2 = new SumExpression();
	e2->add(e1);
	e2->add(one);
	e2->add(b);
	//	e2->add(e1);

	cout << "VisitorPrint:" << endl;
	VisitorPrint visitorPrint;
	cout << "e1 = ";
	e1->accept(visitorPrint);
	cout << endl << "e2 = ";
	e2->accept(visitorPrint);
	cout << endl;

	cout << endl << "VisitorEval:" << endl ;

	State st;
	st.update("a", 10);
	st.update("b", 10);
	
	VisitorEval visitorEval1(st);
	e1->accept(visitorEval1);
	cout << "e1 = " << visitorEval1.getCumulateVal() << endl;
	
	VisitorEval visitorEval2(st);
	e2->accept(visitorEval2);
	cout << "e2 = " << visitorEval2.getCumulateVal() << endl;

	return 0;
}
