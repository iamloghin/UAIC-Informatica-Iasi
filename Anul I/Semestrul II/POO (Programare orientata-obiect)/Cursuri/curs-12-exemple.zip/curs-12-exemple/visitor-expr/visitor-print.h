#ifndef VISITOR_PRINT_H
#define VISITOR_PRINT_H
#include "visitor.h"
#include "expression.h"
#include <iostream>

class VisitorPrint : public Visitor {
public:
	void visitConstant(Constant* constant) {
		cout << " " << constant->getVal() << " ";
	}
	
	void visitVariable(Variable* variable) {
		cout << " " << variable->getName() << " ";
	}

	void visitProdExpression(ProdExpression* prod) {
		cout << " * ";
	}
	void visitSumExpression(SumExpression* prod) {
		cout << " + ";
	}
};
#endif
