#ifndef VISITOR_H
#define VISITOR_H

using namespace std;

class Constant;
class Variable;
class CompoundExpression;
class ProdExpression;
class SumExpression;

class Visitor {
public:
	virtual void visitConstant(Constant*) = 0;
	virtual void visitVariable(Variable*) = 0;
	virtual void visitCompoundExpression(CompoundExpression*) {}
	virtual void visitProdExpression(ProdExpression*) {}
	virtual void visitSumExpression(SumExpression*) {}
protected:
	Visitor(){};
};


#endif
