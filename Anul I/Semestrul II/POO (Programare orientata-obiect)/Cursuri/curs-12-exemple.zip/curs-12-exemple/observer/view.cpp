
#include "view.h"

ViewContact::ViewContact()
{
	menu.addOption((char *)"0. Afisare");
	menu.addOption((char *)"1. Modifica");
	menu.addOption((char *)"2. Exit");
}

/*virtual*/ void ViewContact::Update(void* subject)
{
	cout << endl << "*** Contact view ***" << endl;

	ModelContact* pModel = static_cast<ModelContact*>(subject);

	dbName.setLabel( pModel->getName_Label() );
	dbName.setValue( pModel->getName() );

	dbPhoneNo.setLabel( pModel->getPhoneNo_Label() );
	dbPhoneNo.setValue( pModel->getPhoneNo() );

	dbName.display();
	dbPhoneNo.display();
	
	cout << endl;
} 

int ViewContact::getUserAction()
{
	menu.display();
	return menu.getOption();
}

void ViewContact::getNewContactInformations( ModelContact* pModelContact )
{
	// get info from user
	EditBoxString editBox;
	
	editBox.setLabel( pModelContact->getName_Label() );
	pModelContact->setName( editBox.getValue() );
	
	editBox.setLabel( pModelContact->getPhoneNo_Label() );
	pModelContact->setPhoneNo( editBox.getValue() );

	return;
}

/***********************************************************************************************
*                                                                                              *
*                                                                                              *
***********************************************************************************************/

ViewAgenda::ViewAgenda()
{
	viewContact = new ViewContact;
	
	menu.addOption((char *)"0. Afisare proprietar");
	menu.addOption((char *)"1. Modifica proprietar");
	menu.addOption((char *)"2. Meniu contact");
	menu.addOption((char *)"3. Terminare program");
}

ViewAgenda::~ViewAgenda()
{
	delete viewContact;
}

/*virtual*/ void ViewAgenda::Update(void* subject)
{
	cout << endl << "*** Agenda view ***" << endl;

	ModelAgenda* pModel = static_cast<ModelAgenda*>(subject);

	dbOwner.setLabel( pModel->getOwner_Label() );
	dbOwner.setValue( pModel->getOwner() );

	dbOwner.display();
	
	cout << endl;
}

int ViewAgenda::getUserAction()
{
	menu.display();
	return menu.getOption();
}

ViewContact* ViewAgenda::getViewContact()
{
	return viewContact;
}

void ViewAgenda::getNewAgendaInformations( ModelAgenda* pModelAgenda )
{
	// get info from user
	EditBoxString editBox;
	
	editBox.setLabel( pModelAgenda->getOwner_Label() );
	pModelAgenda->setOwner( editBox.getValue() );

	return;
}


