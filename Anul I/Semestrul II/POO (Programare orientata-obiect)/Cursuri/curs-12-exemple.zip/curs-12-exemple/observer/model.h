#ifndef MODEL_H
#define MODEL_H

#include <string>
#include "observer.h"

// modelul (independent de view)

class ModelContact : /*reuse*/ public ISubject
{
private:
	string name;
	string name_label;

	string phoneNo;
	string phoneNo_label;

public:
	ModelContact();
	~ModelContact(){}

	string getName_Label();
	string getPhoneNo_Label();

	string getName();
	void setName(string newName);

	string getPhoneNo();
	void setPhoneNo(string newPhoneNo); 
};

class ModelAgenda : /*reuse*/ public ISubject
{
private:
	string			owner;
	string			owner_label;
	
	ModelContact*	modelContact;
	string			contact_label;

public:
	ModelAgenda();
	~ModelAgenda();

	string getOwner_Label();
	string getOwner();

	string getContact_Label();
	ModelContact* getModelContact();

	void setOwner(string newOwner);
	void setContact(const ModelContact& newContact);
};

#endif