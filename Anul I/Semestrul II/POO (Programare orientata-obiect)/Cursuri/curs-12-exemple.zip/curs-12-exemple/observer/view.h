#ifndef VIEW_H
#define VIEW_H

#include "utils.h"
#include "observer.h"
#include "model.h"

// un view este observator pentru un model
class ViewContact : public IObserver
{
private:
	// interface elements
	Menu menu;
	DisplayBoxString dbName;
	DisplayBoxString dbPhoneNo;
	
public:

	ViewContact();
	~ViewContact(){}

	/*virtual*/ void Update(void* subject);

	int getUserAction();

	void getNewContactInformations( ModelContact* pModelContact );
};

class ViewAgenda : public IObserver
{
private:
	ViewContact* viewContact;
	
	// interface elements
	Menu menu;
	DisplayBoxString dbOwner;
	ViewContact viewCurrentContact;

public:
	ViewAgenda();
	~ViewAgenda();

	/*virtual*/ void Update(void* subject);

	int getUserAction();
	
	ViewContact* getViewContact();

	void getNewAgendaInformations( ModelAgenda* pModelAgenda );
};

#endif