#include "model.h"
#include "controller.h"
#include "view.h"

int main() 
{
	ModelAgenda* pModel = new ModelAgenda;
	ViewAgenda* pView   = new ViewAgenda;

	ControllerAgenda* pController = new ControllerAgenda( pModel );
	pController->registerViewAgenda( pView );

	pController->run();

	return 0; 
}

