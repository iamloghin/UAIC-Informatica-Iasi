
#include "model.h"

ModelContact::ModelContact() : name_label("Nume: "), phoneNo_label("Telefon: "), name(""), phoneNo("")
{
	return;
}

string ModelContact::getName_Label()
{
	return name_label;
} 

string ModelContact::getPhoneNo_Label()
{
	return phoneNo_label;
} 

string ModelContact::getName()
{
	return name;
}

string ModelContact::getPhoneNo()
{
	return phoneNo;
}

void ModelContact::setName(string newName) 
{
	name = newName;
}

void ModelContact::setPhoneNo(string newPhoneNo) 
{
	phoneNo = newPhoneNo;
}

/***********************************************************************************************
*                                                                                              *
*                                                                                              *
***********************************************************************************************/

ModelAgenda::ModelAgenda() : owner_label("Proprietar: "), owner(""), contact_label("Contact: ")
{
	modelContact = new ModelContact;
	return;
}

ModelAgenda::~ModelAgenda()
{
	delete modelContact;
}

string ModelAgenda::getOwner_Label()
{
	return owner_label;
}

string ModelAgenda::getOwner()
{
	return owner;
}

string ModelAgenda::getContact_Label()
{
	return contact_label;
}

ModelContact* ModelAgenda::getModelContact()
{
	return modelContact;
}

void ModelAgenda::setOwner(string newOwner) 
{
	owner = newOwner;
}

void ModelAgenda::setContact(const ModelContact& newContact) 
{
	(*modelContact) = newContact;
}
