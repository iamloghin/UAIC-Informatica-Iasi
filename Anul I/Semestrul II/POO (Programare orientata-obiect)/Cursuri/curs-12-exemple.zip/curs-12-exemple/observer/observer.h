#ifndef OBSERVER_H
#define OBSERVER_H

#include<iostream>
#include<vector> 

using namespace std;

struct ISubject;

// interfata de observator
class IObserver 
{
public:
	// update
	virtual void Update(void* subject) = 0;
	virtual ~IObserver(){};
}; 

// interfata de subiect
struct ISubject 
{
	// observatorii
	vector<IObserver*> observers;

	// addObserver 
	void addObserver(IObserver* newObserver)
	{
		observers.push_back(newObserver);
		return;
	}
 
	// notifyObservers 
	void notifyObservers() 
	{ 
		for (	vector<IObserver*>::const_iterator observer_iterator=observers.begin();
				observer_iterator!=observers.end();
				++observer_iterator
			) 
		{
			(*observer_iterator)->Update( /*subiectul in cauza*/ this); 
		}
		
		return;
	}

	virtual ~ISubject(){};
};

#endif
