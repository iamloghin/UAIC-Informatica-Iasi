
#include "controller.h"

// un controller se asociaza unui model deja existent
ControllerContact::ControllerContact(ModelContact* newModelContact) : modelContact(newModelContact)
{
	// un view trebuie sa se inregistreze explicit la controller
	viewContact = NULL;
}
	
// un view se inregistreaza la controller
// controller ataseaza view-ul ca observator pentru model
void ControllerContact::registerViewContact(ViewContact* newViewContact )
{
	viewContact = newViewContact;
	modelContact->addObserver( viewContact);
}

bool ControllerContact::listen() 
{
	if ( NULL == viewContact )
	{
		cout << "Eroare! Controller-ul de Contact nu are asociat un view!" << endl;
		return false;
	}

	int option = viewContact->getUserAction();

	switch (option)
	{
		case 0 : // afisare (actualizare view)
				modelContact->notifyObservers();
				break;

		case 1 : {
					// auxiliar object
					ModelContact* pNewModelContact = new ModelContact;

					// obtine noile informatii de la view
					viewContact->getNewContactInformations( pNewModelContact );

					// valideaza noile informatii
					ValidateModelContact( pNewModelContact );

					// actualizeaza modelul
					modelContact->setName( pNewModelContact->getName() );
					modelContact->setPhoneNo( pNewModelContact->getPhoneNo() );

					// sterge obiectul auxiliar
					delete pNewModelContact;

					// afisare (actualizare view)
					modelContact->notifyObservers();
				 };
				 break;
		case 2 : return false;

		default : cout << "Eroare! Optiune gresita!" << endl;
				  return true;
	}

	return true;
}

bool ControllerContact::ValidateModelContact( ModelContact* pModelContact )
{
	// intotdeauna valid (deocamdata)
	return true;
}

bool ControllerContact::run()
{
	modelContact->notifyObservers();
		
	while (true)
	{
		if ( false == listen() )
		{
			// s-a produs o eroare
			return false;
		}
	}
}

/***********************************************************************************************
*                                                                                              *
*                                                                                              *
***********************************************************************************************/

// un controller se asociaza unui model deja existent
ControllerAgenda::ControllerAgenda(ModelAgenda* newModelAgenda) : modelAgenda(newModelAgenda)
{
	// un view trebuie sa se inregistreze explicit la controller
	viewAgenda = NULL;

	controllerContact = new ControllerContact( modelAgenda->getModelContact() );
}

ControllerAgenda::~ControllerAgenda()
{
	delete controllerContact;
}
	
// un view se inregistreaza la controller
// controller ataseaza view-ul ca observator pentru model
void ControllerAgenda::registerViewAgenda(ViewAgenda* newViewAgenda )
{
	viewAgenda = newViewAgenda;
	modelAgenda->addObserver( viewAgenda);
	
	//modelAgenda->getModelContact()->addObserver( viewAgenda->getViewContact() );
	controllerContact->registerViewContact( viewAgenda->getViewContact() );

	return;
}

bool ControllerAgenda::listen() 
{
	if ( NULL == viewAgenda )
	{
		cout << "Eroare! Controller-ul de Agenda nu are asociat un view!" << endl;
		return false;
	}

	int option = viewAgenda->getUserAction();

	switch (option)
	{
		case 0 : // afisare (actualizare view)
				modelAgenda->notifyObservers();
				break;

		case 1 : {
					// auxiliar object
					ModelAgenda* pNewModelAgenda = new ModelAgenda;

					// obtine noile informatii de la view
					viewAgenda->getNewAgendaInformations( pNewModelAgenda );

					// valideaza noile informatii
					ValidateModelAgenda( pNewModelAgenda );

					// actualizeaza modelul
					modelAgenda->setOwner( pNewModelAgenda->getOwner() );
					
					// sterge obiectul auxiliar
					delete pNewModelAgenda;

					// afisare (actualizare view)
					modelAgenda->notifyObservers();
				 };
				 break;

		case 2 : controllerContact->run();
				 break;;
				 
		case 3 : return false;

		default : cout << "Eroare! Optiune gresita!" << endl;
				  return true;
	}

	return true;
}

bool ControllerAgenda::ValidateModelAgenda( ModelAgenda* pModelAgenda )
{
	// intotdeauna valid (deocamdata)
	return true;
}

bool ControllerAgenda::run()
{
	modelAgenda->notifyObservers();

	while (true)
	{
		if ( false == listen() )
		{
			// s-a produs o eroare
			return false;
		}
	}
	
}