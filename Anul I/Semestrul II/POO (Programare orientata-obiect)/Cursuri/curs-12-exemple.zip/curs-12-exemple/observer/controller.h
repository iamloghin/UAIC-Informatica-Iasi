#ifndef CONTROLLER_H
#define CONTROLLER_H

#include "model.h"
#include "view.h"

class ControllerContact
{
private:
	ModelContact* modelContact;
	ViewContact*  viewContact;

public:

	ControllerContact(ModelContact* newModelContact);
	~ControllerContact(){}
	
	void registerViewContact(ViewContact* newViewContact );

	bool listen(); 

	bool ValidateModelContact( ModelContact* pModelContact );

	bool run();
};


class ControllerAgenda
{
private:
	ControllerContact* controllerContact;
	ModelAgenda* modelAgenda;
	ViewAgenda*  viewAgenda;

public:

	ControllerAgenda(ModelAgenda* newModelAgenda);
	~ControllerAgenda();

	void registerViewAgenda(ViewAgenda* newViewAgenda );

	bool listen(); 

	bool ValidateModelAgenda( ModelAgenda* pModelAgenda );

	bool run();
};

#endif