#ifndef UTILS_H
#define UTILS_H

#include <iostream>
#include <string>

using namespace std;

class DisplayBoxString
{
private:
	string label;
	string value;

public:
	DisplayBoxString(char* newLabel = (char *)"")
	{
		label = newLabel;
	}
	void setLabel(string newLabel)
	{
		label = newLabel;
	}
	void setValue(string newValue)
	{
		value = newValue;
	}
	void display()
	{
		cout << label.c_str() << ":  " << value.c_str() << endl;
	}
};

class EditBoxString
{
private:
	string label;
public:

	EditBoxString(char *newLabel = (char *)"")
	{
		label = newLabel;
	}
	
	void setLabel(string newLabel)
	{
		label = newLabel;
	}
	
	string getValue()
	{
		char buffer[80];
		cout << label.c_str() << ":  ";
		cin >> buffer;
		return string(buffer);
	}
};

class Menu
{
private:
	string options[25];
	int size;

public:
	Menu()
	{
		size = 0;
	}
public:
	void addOption(char* newOption)
	{
		options[size++] = string(newOption);
	}
public:
	void display()
	{
		int i;
		cout << "Menu:" << endl;
		for (i = 0; i < size; ++i)
			cout << options[i].c_str() << endl;
	}
public:
	int getOption()
	{
		int option;
		cout << "Option: ";
		cin >> option;
		return option;
	}
};

#endif
