#ifndef VISITOR_PRINT_H
#define VISITOR_PRINT_H
#include "visitor.h"
#include "pgm.h"
#include <iostream>

class VisitorPrint : public Visitor {
public:
	void visitDecl(Decl* decl) {
		cout << decl->getType() << " " << decl->getName() << ";" << endl;
	}
	void visitAssign(Assign* assign) {
		cout << assign->getLhs() << " = ";
		(assign->getRhs()).accept(*this);
		cout << ";" << endl;
	}
	void visitConstant(Constant* constant) {
		cout << " " << constant->getVal() << " ";
	}
	
	void visitVariable(Variable* variable) {
		cout << " " << variable->getName() << " ";
	}

	void visitProdExpression(ProdExpression* prod) {
		cout << " * ";
	}
	void visitSumExpression(SumExpression* prod) {
		cout << " + ";
	}
};
#endif
