#include "expression.h"
#include "state.h"
#include "pgm.h"
#include "visitor-print.h"
#include "visitor-eval.h"
#include "visitor-exec.h"
#include <iostream>

int main()
{
	Constant* one = new Constant(1);
	Constant* two = new Constant(2);
	Variable *a = new Variable("a");
	Variable *b = new Variable("b");

	ProdExpression* e1 =  new ProdExpression();
	e1->add(two);
	e1->add(a);
	SumExpression* e2 = new SumExpression();
	e2->add(e1);
	e2->add(one);
	e2->add(b);

	Decl* decl1 = new Decl("int", "a");
	Decl* decl2= new Decl("int", "b");
	Assign* assign1 = new Assign("a", e1);
	Assign* assign2= new Assign("b", e2);

	Pgm pgm;
	pgm.insert(decl1);
	pgm.insert(decl2);
	pgm.insert(assign1);
	pgm.insert(assign2);

	cout << "VisitorPrint:" << endl;

	VisitorPrint visitorPrint;
	pgm.accept(visitorPrint);
	
	State st;
	st.update("a", 10);
	st.update("b", 20);

	
	cout << endl << "VisitorEval:" << endl ;
	cout << "State: " << endl;
	st.print();

	VisitorEval visitorEval1(st);
	e1->accept(visitorEval1);
	cout << "e1 = " << visitorEval1.getCumulateVal() << endl;
	VisitorEval visitorEval2(st);
	e2->accept(visitorEval2);
	cout << "e2 = " << visitorEval2.getCumulateVal() << endl;

//	e1->remove();

	cout << endl << "VisitorExec:" << endl;

	VisitorExec visitorExec;
	pgm.accept(visitorExec);
	visitorExec.getState().print();

	return 0;
}
