#ifndef VISITOR_EVAL_H
#define VISITOR_EVAL_H
#include "visitor.h"
#include "expression.h"
#include "state.h"
#include <iostream>
#include <stack>

class VisitorEval : public Visitor {
public:
  
	virtual void visitDecl(Decl*) {}

	virtual void visitAssign(Assign*) {}
	
	VisitorEval(State aState)
	{
		state = aState;
	}

	void visitConstant(Constant* constant) {
		valStack.push(constant->getVal());
	}
	
	void visitVariable(Variable* variable) {
		valStack.push(state.lookup(variable->getName()));
	}

	void visitProdExpression(ProdExpression* prod) {
		int temp = 1;
		for (int i = 0; i < prod->size() ; ++i) {
			temp *= valStack.top();
			valStack.pop();
		}
		valStack.push(temp);
	}
	void visitSumExpression(SumExpression* sum) {
		int temp = 0;
		for(int i = 0; i < sum->size(); ++i) {
			temp += valStack.top();
			valStack.pop();
		}
		valStack.push(temp);
	}
	int getCumulateVal() {
	  return valStack.top();
	}
private:
	State state;
	stack<int> valStack;
};
#endif
