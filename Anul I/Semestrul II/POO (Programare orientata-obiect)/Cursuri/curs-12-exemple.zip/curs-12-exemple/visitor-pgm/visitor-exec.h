#ifndef VISITOR_EXEC_H
#define VISITOR_EXEC_H
#include "visitor.h"
#include "pgm.h"
#include "visitor-eval.h"
#include <iostream>

class VisitorExec : public Visitor {
public:
	void visitDecl(Decl* decl) {
		if (decl->getType() == "int") {
			state.update(decl->getName(), 0);
		}
	}
	void visitAssign(Assign* assign) {
		VisitorEval evalExpr(state);
		(assign->getRhs()).accept(evalExpr);
		state.update(assign->getLhs(), evalExpr.getCumulateVal());
	}
	void visitConstant(Constant* constant) { }
	
	void visitVariable(Variable* variable) { }

	State& getState() {return state;}

private:
	State state;
};
#endif
