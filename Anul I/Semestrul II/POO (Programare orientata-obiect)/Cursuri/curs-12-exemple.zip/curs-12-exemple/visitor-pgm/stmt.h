#ifndef STMT_H
#define STMT_H
#include "expression.h"
#include "visitor.h"
#include <string>

class Stmt {
public:
	virtual void accept(Visitor&) {}
};

class Decl : public Stmt {
public:
	Decl(string type="", string name=""){
		varType = type;
		varName = name;
	}
	string getType() { return varType;}
	string getName() { return varName;}

	void accept(Visitor& visitor) {
		visitor.visitDecl(this);
	}
private:
	string varType;
	string varName;
};

class Assign : public Stmt {
public:
	Assign(string var, Expression* expr) {
		lhs = var;
		rhs = expr;
	}
	string getLhs() { return lhs;}
	Expression& getRhs() { return *rhs;}

	void accept(Visitor& visitor) {
		visitor.visitAssign(this);
	}
private:
	string lhs;
	Expression* rhs;
};
#endif
