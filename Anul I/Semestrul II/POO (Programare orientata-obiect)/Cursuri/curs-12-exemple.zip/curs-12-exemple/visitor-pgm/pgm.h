#ifndef PGM_H
#define PGM_H
#include "stmt.h"
#include "visitor.h"
#include <list>

class Pgm {
public:
	void insert(Stmt* stmt) {stmts.push_back(stmt);}

	virtual void accept(Visitor& visitor) {
		list<Stmt*>::iterator it;
		for(it = stmts.begin(); it != stmts.end(); ++it) {
			(*it)->accept(visitor);
		}
	}
private:
	list<Stmt*> stmts;
};

#endif
