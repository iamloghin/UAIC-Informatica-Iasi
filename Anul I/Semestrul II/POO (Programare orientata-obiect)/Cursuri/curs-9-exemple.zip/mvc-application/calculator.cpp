#include "calculator.h"
#include <iostream>


Calculator::Calculator() {
  reg0 = reg1 = reg2 = 0;
  act = prevAct = none;
}

Calculator::~Calculator() {
}

void Calculator::plus() {
  setAct(tplus);
  switch (prevAct)
    {
    case none :
      break;
    case tplus :
      reg0 += reg1;
      break;
    case tminus :
      reg0 -= reg1;
      break;
    case tmult :
      reg0 *= reg1;
      break;
    case tdiv :
      reg0 /= reg1;
      break;
    }
}

void Calculator::minus() {
  setAct(tminus);
  switch (prevAct)
    {
    case none :
      break;
    case tplus :
      reg0 += reg1;
      break;
    case tminus :
      reg0 -= reg1;
      break;
    case tmult :
      reg0 *= reg1;
      break;
    case tdiv :
      reg0 /= reg1;
      break;
    }
}

void Calculator::mult() {
  setAct(tmult);
  switch (prevAct)
    {
    case none :
      break;
    case tplus :
      setPrevAct(tplus);
      break;
    case tminus :
      setPrevAct(tminus);
      break;
    case tmult :
      reg0 *= reg1;
      execPrevAct();
      break;
    case tdiv :
      reg0 /= reg1;
      execPrevAct();
      break;
    }
}

void Calculator::div() {
  setAct(tdiv);
  switch (prevAct)
    {
    case none :
      break;
    case tplus :
      setPrevAct(tplus);
      break;
    case tminus :
      setPrevAct(tminus);
      break;
    case tmult :
      reg0 *= reg1;
      execPrevAct();
      break;
    case tdiv :
      reg0 /= reg1;
      execPrevAct();
      break;
    }
}

int Calculator::getReg() const {
  return reg0;
}


void Calculator::setReg(int x)  {
  reg2 = reg1;
  reg1 = reg0;
  reg0 = x;
}

void Calculator::setAct(Action a) {
  act = a;
}


void Calculator::setPrevAct(Action a) {
  prevAct = a;
}

void Calculator::execPrevAct() {
  switch (prevAct)
    {
    case none :
      break;
    case tplus :
      reg0 += reg2;
      break;
    case tminus :
      reg0 -= reg2;
      break;
    case tmult :
      reg0 *= reg2;
      break;
    case tdiv :
      reg0 /= reg2;
      break;
    }
  setPrevAct(none);
}

void Calculator::equal() {
  
  switch (act)
    {
    case none :
      break;
    case tplus :
      reg0 += reg1;
      break;
    case tminus :
      reg0 -= reg1;
      break;
    case tmult :
      reg0 *= reg1;
      break;
    case tdiv :
      reg0 /= reg1;
      break;
    }
  execPrevAct();
}
