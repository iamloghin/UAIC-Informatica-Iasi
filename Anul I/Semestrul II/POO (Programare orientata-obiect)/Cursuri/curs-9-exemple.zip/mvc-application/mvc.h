#ifndef MVC_H
#define MVC_H

class Model {
  virtual void update() { }
};

class Controller;

class View
{
 protected:
  Model *model;
  Controller *controller;
 public:
        View()
	     {
	       // nothing
	     }
	virtual void create() = 0;   // pure virtual method
	virtual void update() {};    // empty method
	virtual bool display() = 0;  // pure virtual method
	virtual void setModel(Model *aModel)
	{
		model = aModel;
	}    
	virtual void setController(Controller *aController)
	{
		controller = aController;
	}
};


class Controller
{
protected:
	View *view;
	Model *model;
public:
	Controller()
	  {
	    // nothing
	  }
	virtual void setView(View *aView)
	{
		view = aView;
	}
	
	virtual void setModel(Model *aModel)
	{
		model = aModel;
	}
};

// template < class M, class V, class C >
class Mvc
{
private:
	Controller *c;
	View *v;
	Model *m;
public:
	Mvc(Model *aModel = 0, View *aView = 0, Controller *aController = 0)
	{
		m = aModel;
		v = aView;
		c = aController;
		v->setModel(m);
		v->setController(c);
		c->setModel(m);
		c->setView(v);
	}
public:
	~Mvc()
	{
	  // nothing
	}
public:
	void run()
	{
		while (v->display())
		{
			//nothing
		}
	}
};
#endif
