// demo.cpp : Defines the entry point for the console application.
//

#include "controller-calculator.h"
#include "view-calculator.h"
#include "mvc.h"

int main()
{
	Calculator *model = new Calculator();
	ViewCalculator *view = new ViewCalculator();
	ControllerCalculator *controller = new ControllerCalculator();
	//Mvc<Calculator, ViewCalculator, ControllerCalculator> mvcCalculator(model);
	Mvc mvcCalculator(model, view, controller);
	mvcCalculator.run();

	return 0;
}

