#ifndef TUI_H
#define TUI_H
#include <iostream>
#include <string>

// Textual User Interface class library 

using namespace std;

class Menu
{
private:
	string options[25];
private:
	int size;
public:
	Menu()
	{
		size = 0;
	}
public:
	void addOption(const char *newOption)
	{
		options[size++] = string(newOption);
	}
public:
	void display()
	{
		int i;
		cout << "Menu:" << endl;
		for (i = 0; i < size; ++i)
			cout << options[i].c_str() << endl;
	}
public:
	int getOption()
	{
		int option;
		cout << "Option: ";
		cin >> option;
		return option;
	}
};

template <class T>
class DisplayBox
{
private:
	string label;
private:
	T value;
public:
	DisplayBox(const char *newLabel = "")
	{
		label = newLabel;
	}
public:
	void setLabel(string newLabel)
	{
		label = newLabel;
	}
public:
	void setValue(T newValue);
public:
	void display();
};

template <class T>
void DisplayBox<T>::setValue(T newValue)
	{
		value = newValue;
	}

template <class T>
void DisplayBox<T>::display()
	{
		cout << label.c_str() << ":  " << value << endl;
	}

template <class T>
class EditBox
{
private:
	string label;
private:
	T value;
public:
	EditBox(const char *newLabel = "")
	{
		label = newLabel;
	}
public:
	void setLabel(string newLabel)
	{
		label = newLabel;
	}
public:
	T getValue()
	{
		T buffer;
		cout << label.c_str() << ":  ";
		cin >> buffer;
		return buffer;
	}
};

#endif

