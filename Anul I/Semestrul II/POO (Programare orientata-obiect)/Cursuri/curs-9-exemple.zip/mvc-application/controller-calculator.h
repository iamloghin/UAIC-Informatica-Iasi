#ifndef CONTROLLER_CALCULATOR_H
#define CONTROLLER_CALCULATOR_H
#include "calculator.h" 
#include "mvc.h"
#include <stdlib.h>
#include <iostream>

using namespace std;

class ControllerCalculator : public Controller
{
private:
  // Calculator *model;
public:
        ControllerCalculator()
	{
	  // nothing
	}
public:
	void execute(int option)
	{
	        Calculator &cmodel = dynamic_cast<Calculator&>(*model);
	        int newValue;
		switch (option)
		{
			case 0:
			  break;
			case 1: 
			  cmodel.plus();
			  break;
			case 2: 
			  cmodel.minus();
			  break;
			case 3: 
			  cmodel.mult();
			  break;
			case 4: 
			  cmodel.div();
			  break;
			case 5: 
			  cmodel.equal();
			  break;
			case 6:
			  cout << "New value: ";
			  cin >> newValue;
			  cmodel.setReg(newValue);
			  break;
			default: exit(1);
		}
	}
};

#endif 
