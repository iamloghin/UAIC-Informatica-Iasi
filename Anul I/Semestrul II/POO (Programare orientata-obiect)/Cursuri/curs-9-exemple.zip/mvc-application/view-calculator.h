#ifndef VIEW_CALCULATOR_H
#define VIEW_CALCULATOR_H
#include "calculator.h"
#include "controller-calculator.h"
#include "tui.h"

using namespace std;

class ViewCalculator : public View
{
private:
  // Calculator *model;
  // ControllerCalculator *controller;
	DisplayBox<int> dbVal;
	Menu menu;
public:
	ViewCalculator()
	{
	  create();
	};
public:
	void create()
	{
		menu.addOption("1. Plus");
		menu.addOption("2. Minus");
		menu.addOption("3. Mult");
		menu.addOption("4. Div");
		menu.addOption("5. Equal");
		menu.addOption("6. Value");
		menu.addOption("0. Exit");
		dbVal.setLabel("Result");
	}
public:
	void update()
	{
	  Calculator &cmodel = dynamic_cast<Calculator&>(*model);
	  dbVal.setValue(cmodel.getReg());
	}
public:
	bool display()
	{
	        ControllerCalculator &ccontroller = dynamic_cast<ControllerCalculator&>(*controller);
		int option;
		cout << endl << "*** Calculator view ***" << endl;
		update();
		dbVal.display();
		menu.display();
		option = menu.getOption();
		if (option != 0)
		{
			ccontroller.execute(option);
			return true;
		}
		else
			return false;
	}
};
#endif
