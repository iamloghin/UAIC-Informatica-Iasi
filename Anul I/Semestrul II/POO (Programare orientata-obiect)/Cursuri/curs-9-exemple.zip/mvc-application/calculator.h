#ifndef CALCULATOR_H
#define CALCULATOR_H
#include "mvc.h"
#include <string>
using namespace std;


enum Action { none = 0, tplus, tminus, tmult, tdiv };

class Calculator : public Model
{
public:
	Calculator();
	~Calculator();
	void plus();
	void minus();
	void mult();
	void div();
	void equal();
	int getReg() const;
	void setReg(int);
	void setAct(Action);
	void setPrevAct(Action);
private:
	int reg0, reg1, reg2;   // reg0 is the top
	Action act, prevAct;
	void execPrevAct();
};

#endif
