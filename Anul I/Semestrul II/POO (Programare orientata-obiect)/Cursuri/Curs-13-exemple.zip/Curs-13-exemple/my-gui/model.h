#ifndef MODEL
#define MODEL
#include "my-gui.h"

class MyDisplayBox;

class Model {
 public:
  Model(int ch = -1, std::string inp = "");
  void setLastChoice(int ch);
  int getLastChoice() const;
  void setLastInput(std::string inp);
  std::string getLastInput() const;
  void setChView(MyDisplayBox *db);
  void setInpView(MyDisplayBox *db);
  void notify() const;
 private:
  int lastChoice;
  std::string lastInput;
  MyDisplayBox *chView, *inpView;
};

#endif
