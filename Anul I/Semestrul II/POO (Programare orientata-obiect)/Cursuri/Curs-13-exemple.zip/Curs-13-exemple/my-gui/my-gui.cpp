#include "my-gui.h"

// MyWindow class

MyWindow::MyWindow(Point pos, int w, int h, const char *title) :
  Fl_Window(pos.getX(), pos.getY(), w, h, title)
{
  //nothing
}

MyWindow::MyWindow(int w, int h, const char *title) :
  Fl_Window(w, h, title)
{
  //nothing
}

int MyWindow::display() {
    this->end();    // inherited
    this->show();   // inherited
    return Fl::run();
 }

// MyDisplayBox class

MyDisplayBox::MyDisplayBox(Point pos, int w, int h, const char *label) :
  Fl_Output(pos.getX(), pos.getY(), w, h, label)
{
  //nothing
}

void MyDisplayBox::setText(std::string txt) {
    this->value(txt.data());   // inherited
    this->redraw();     // inherited
} 

// MyReturnButton class

MyReturnButton::MyReturnButton(Point pos, int w, int h, const char *label) :
  Fl_Return_Button(pos.getX(), pos.getY(), w, h, label)
{
    this->tooltip("Push Return button to exit");
    this->labelsize(12);
    this->callback((Fl_Callback*) ret_cb);
    this->redraw();
}

void MyReturnButton::ret_cb(Fl_Button *b, void *) {
    exit(0);
}

// MyRadioButton class

MyRadioButton::MyRadioButton(Point pos, int w, int h, std::string slabel) :
  Fl_Radio_Round_Button(pos.getX(), pos.getY(), w, h)
{
    this->tooltip("Radio button, only one button is set at a time.");
    this->down_box(FL_ROUND_DOWN_BOX);
    this->callback((Fl_Callback*) radio_button_cb);
    this->when(FL_WHEN_CHANGED);
    std::strcpy(blabel, slabel.c_str());
    this->label(blabel);   // sets only the address of the buffer
    this->redraw();
}

void MyRadioButton::setController(Controller *aCntrl) {
    controller = aCntrl;
}

//void MyRadioButton::radio_button_cb(MyRadioButton *b, void *) {}
void MyRadioButton::radio_button_cb(MyRadioButton *b, void *) {
  b->controller->chControl(std::string(b->label()));
}

// MyRadioGroup class

MyRadioGroup::MyRadioGroup(Point pos, int w, int h,  std::string slabel, int no) :
  Fl_Group(pos.getX(), pos.getY(), w, h)
{
    int i;
    this->box(FL_THIN_UP_FRAME);
    Point bpos = pos;
    MyRadioButton *b;
    for (i = 0; i < no; ++i) {
      bpos.setY(pos.getY() + i*30);
      b = new MyRadioButton(bpos, 100, h/no, slabel.data()+std::to_string(i));
      elts.push_back(b);
    }
    noOfElts = no;
    this->end();
}

void MyRadioGroup::setController(Controller *aCntrl) {
    int i;
    for (i = 0; i < noOfElts; ++i)
      elts[i]->setController(aCntrl);
}

// MyEditBox class

MyEditBox::MyEditBox(Point pos, int w, int h, char * label) :
  Fl_Multiline_Input(pos.getX(), pos.getY(), w, h, label)
{
    this->tooltip("Input field for short text with newlines.");
    this->wrap(1);
    //    this->when(0);
    this->when(FL_WHEN_RELEASE);
    this->callback((Fl_Callback*) input_cb);
    this->show();
}

void MyEditBox::setController(Controller *aCntrl) {
    controller = aCntrl;
}

//void MyEditBox::input_cb(MyEditBox *eb, void *) {}
void MyEditBox::input_cb(MyEditBox *eb, void *) {
  eb->controller->inpControl(std::string(eb->value()));
}




