#ifndef POINT_GUARD
#define POINT_GUARD

class Point {
 public:
  Point(int xx = 0, int yy = 0) : x(xx), y(yy) { }
  int getX() { return x; }
  int getY() { return y; }
  void setX(int newX) { x = newX; }
  void setY(int newY) { y = newY; }
 private:
  int x,y;
};

inline bool operator==(Point a, Point b) { return a.getX()==b.getX() && a.getY()==b.getY(); }

inline bool operator!=(Point a, Point b) { return !(a==b); }

#endif
