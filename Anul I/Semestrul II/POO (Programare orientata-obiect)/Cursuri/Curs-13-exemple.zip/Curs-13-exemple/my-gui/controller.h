#ifndef CNTRL
#define CNTRL
#include "model.h"

class Model;

class Controller {
 public:
  void chControl(std::string aString);
  void inpControl(std::string  aString);
  void setModel(Model *aModel);
 private:
  Model *model;
};
#endif
