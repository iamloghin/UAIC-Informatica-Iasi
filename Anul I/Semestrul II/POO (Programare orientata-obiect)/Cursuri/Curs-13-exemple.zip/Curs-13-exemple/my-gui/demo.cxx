#include "my-gui.h"
#include "model.h"
#include "controller.h"

/*
void cb(Fl_Widget *ob) {
  //printf("Callback for %s '%s'\n",ob->label(),((Fl_Input*)ob)->value());
  std::cout << "Callback for " << ob->label() << ((Fl_Input*)ob)->value();
}

void test(Fl_Input *i) {
  if (i->changed()) {
    i->clear_changed(); printf("%s '%s'\n",i->label(),i->value());
    char utf8buf[10];
    int last = fl_utf8encode(i->index(i->position()), utf8buf);
    utf8buf[last] = 0;
    // printf("Symbol at cursor position: %s\n", utf8buf);
    std::cout << "Symbol at cursor position:\n" << utf8buf << std::endl;
  }
}


Fl_Multiline_Input *inp;

void button_cb(Fl_Widget *,void *) {
  test(inp);
}

*/

int main() {

  Point posMainWindow(100, 200);
  MyWindow* mainwindow = new MyWindow(posMainWindow, 600, 400);
  
  Point posFirstDB(100, 50);
  MyDisplayBox *adb = new MyDisplayBox(posFirstDB, 150, 50, "1st display box");
  adb->setText("My first output text.");
  
  
  Point posRet(400, 350);
  MyReturnButton *ret = new MyReturnButton(posRet, 100, 25, "&Return");
   
  Point posRG(100, 150);
  MyRadioGroup *rg = new MyRadioGroup(posRG, 150, 90, "MyChoice ", 3);
  
  Model model(-1, "nothing");
  Controller chCntrl;
  model.setChView(adb);
  chCntrl.setModel(&model);
  rg->setController(&chCntrl);
  
  Point posEB(350, 150);
  MyEditBox *eb = new MyEditBox(posEB, 150, 100, (char *)"&My Input");
   
  
  Point posSndDB(375, 50);
  MyDisplayBox *snddb = new MyDisplayBox(posSndDB, 200, 50, "2nd display box");
  snddb->setText("My second output text.");

  Point posTrdDB(200, 275);
  MyDisplayBox *trddb = new MyDisplayBox(posTrdDB, 200, 50, "3rd display box");
  trddb->setText("My third output text.");

  eb->setController(&chCntrl);
  model.setInpView(snddb);
  model.setChView(trddb);
  
  return mainwindow->display();
};

