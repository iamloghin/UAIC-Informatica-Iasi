#include "model.h"

Model::Model(int ch, std::string inp) : lastChoice(ch), lastInput(inp) {}

void Model::setLastChoice(int ch) {
  lastChoice = ch;  notify();
}

int Model::getLastChoice() const {
  return lastChoice;
}

void Model::setLastInput(std::string inp) {
  lastInput = inp; notify();
}

std::string Model::getLastInput() const {
  return lastInput;
}

void Model::setChView(MyDisplayBox *db) {
  chView = db;
}

void Model::setInpView(MyDisplayBox *db) {
  inpView = db;
}

void Model::notify() const {
  chView->setText(std::string("Last choice is ") + std::to_string(lastChoice));
  inpView->setText(std::string("Last input is `") + lastInput + std::string("`"));
}
 
