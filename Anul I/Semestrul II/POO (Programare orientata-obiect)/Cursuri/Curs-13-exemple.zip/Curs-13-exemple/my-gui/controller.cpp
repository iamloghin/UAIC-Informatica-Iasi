#include "controller.h"

void Controller::chControl(std::string btnLabel) {
    if (btnLabel == "MyChoice 0") model->setLastChoice(0); 
    else if (btnLabel == "MyChoice 1") model->setLastChoice(1); 
    else if (btnLabel == "MyChoice 2") model->setLastChoice(2); 
    else model->setLastChoice(-1);
}

void Controller::inpControl(std::string anInput) {
   model->setLastInput(anInput);
}

void Controller::setModel(Model *aModel) {
  model = aModel; 
}
