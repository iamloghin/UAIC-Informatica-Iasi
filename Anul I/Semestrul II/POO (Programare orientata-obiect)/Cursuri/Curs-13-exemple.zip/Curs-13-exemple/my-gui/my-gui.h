#ifndef MYGUI_GUARD
#define MYGUI_GUARD

#include "point.h"
#include <string>
#include <vector>
#include <iostream>
#include <cstdlib>

#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Double_Window.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Return_Button.H>
#include <FL/Fl_Light_Button.H>
#include <FL/Fl_Check_Button.H>
#include <FL/Fl_Round_Button.H>
#include <FL/Fl_Radio_Round_Button.H>
#include <FL/Fl_Group.H>
#include <FL/Fl_Output.H>
#include <FL/Fl_Input.H>
#include <FL/Fl_Multiline_Input.H>
#include "controller.h"


// MyWindow class

class MyWindow : Fl_Window {
 public:
  MyWindow(Point pos, int w, int h, const char *title = 0);
  MyWindow(int w, int h, const char *title = 0);

  int display();
};


// MyDisplayBox class

class MyDisplayBox : Fl_Output {
 public:
  MyDisplayBox(Point pos, int w, int h, const char *label = 0);

  void setText(std::string txt);
};

// MyReturnButton class

class MyReturnButton : Fl_Return_Button {
 public:
  MyReturnButton(Point pos, int w, int h, const char *label = 0);
  
 private:
  static void ret_cb(Fl_Button *b, void *);
};


// MyRadioButton class

 class Controller;

class MyRadioButton : Fl_Radio_Round_Button {
 public:
  MyRadioButton(Point pos, int w, int h, std::string slabel);
  void setController(Controller *aCntrl);
  
 private:
  char blabel[256];  //  the buffer storing the label
  Controller *controller;
  static void radio_button_cb(MyRadioButton *b, void *);
};


// MyRadioGroup class

class MyRadioGroup : Fl_Group {
 public:
  MyRadioGroup(Point pos, int w, int h,  std::string slabel, int no);

  void setController(Controller *aCntrl);
  
 private:
  int noOfElts;
  std::vector<MyRadioButton *> elts;
};


// MyEditBox class

class MyEditBox : public Fl_Multiline_Input {
 public:
  MyEditBox(Point pos, int w, int h, char * label);
  
  void setController(Controller *aCntrl);
 private:
  Controller *controller;
  static void input_cb(MyEditBox *eb, void *);
};

#endif
