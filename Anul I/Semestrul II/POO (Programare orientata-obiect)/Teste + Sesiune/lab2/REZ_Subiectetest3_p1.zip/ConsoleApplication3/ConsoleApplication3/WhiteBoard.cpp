#include "WhiteBoard.h"

WhiteBoard::WhiteBoard(Message* parinte_, int x_, int y_, string text_, string culoare_)
{
	this->parinte = parinte_;
	x = x_;
	y = y_;
	text = text_;
	culoare = culoare_;

	alte_mesaje.clear();
}

void WhiteBoard::Afiseaza()
{
	cout << "text: " << text;
	cout << "; culoare:" << culoare;
	cout << "; x:" << x;
	cout << "; y:" << y;
	cout << "; nr_atasamente:" << alte_mesaje.size();
	cout << "; parinte: ";

	if (parinte != NULL)
		cout << parinte->GetContent();
	else
		cout << "---";

	cout << endl;

	vector <Message*>::iterator it;

	for (it = alte_mesaje.begin(); it != alte_mesaje.end(); it++)
		(*it)->Afiseaza();
}

void WhiteBoard::Attach(Message* m)
{
	alte_mesaje.push_back(m);
}

int WhiteBoard::GetX()
{
	return x;
}
int WhiteBoard::GetY()
{
	return y;
}
string WhiteBoard::GetContent()
{
	return text;
}