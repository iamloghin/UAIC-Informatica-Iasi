#pragma once

#include "Message.h"

class Sticker : public Message
{
private:
	int x;
	int y;
	string text;
	string culoare;

	vector<Message*> alte_mesaje;

	Message* parinte;

public:
	Sticker(Message* parinte_, int x_, int y_, string text_, string culoare_);
	void Afiseaza();
	void Attach(Message* m);
	int GetX();
	int GetY();
	string GetContent();
};
