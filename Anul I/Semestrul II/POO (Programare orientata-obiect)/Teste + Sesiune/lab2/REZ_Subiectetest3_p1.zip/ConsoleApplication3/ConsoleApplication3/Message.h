#pragma once

#include <string>
#include <vector>
#include <iostream>

using namespace std;

class Message
{
public:
	virtual void Afiseaza() = 0;
	virtual void Attach(Message* m) = 0;
	virtual int GetX() = 0;
	virtual int GetY() = 0;
	virtual string GetContent() = 0;
};
