#include "Sticker.h"

Sticker::Sticker(Message* parinte_, int x_, int y_, string text_, string culoare_)
{
	this->parinte = parinte_;
	x = x_;
	y = y_;
	text = text_;
	culoare = culoare_;

	alte_mesaje.clear();
}

void Sticker::Afiseaza()
{
	cout << "text: " << text;
	cout << "; culoare:" << culoare;
	cout << "; x:" << x;
	cout << "; y:" << y;
	cout << "; nr_atasamente:" << alte_mesaje.size();
	cout << "; parinte: ";

	if (parinte != NULL)
		cout << parinte->GetContent();
	else
		cout << "---";

	cout << endl;

	vector <Message*>::iterator it;

	//for (auto it = alte_mesaje.begin(); it != alte_mesaje.end(); it++)
	for (it = alte_mesaje.begin(); it != alte_mesaje.end(); it++)
		(*it)->Afiseaza();
}

void Sticker::Attach(Message* m)
{
	alte_mesaje.push_back(m);
}

int Sticker::GetX()
{
	return x;
}
int Sticker::GetY()
{
	return y;
}
string Sticker::GetContent()
{
	return text;
}