#pragma once

#include "stdafx.h"
#include "MasinaOras.h"

class Opel : public MasinaOras
{
	int capacitate;
	string culoare;
	int anFabricatie;
public:
	void setCapacitate(int capacitate_);
	void setCuloare(string culoare_);
	void setAnFabricatie(int fabricatie_);
	int getAnFabricatie();
	int getCapacitate();
	string getCuloare();
	string getName();
};