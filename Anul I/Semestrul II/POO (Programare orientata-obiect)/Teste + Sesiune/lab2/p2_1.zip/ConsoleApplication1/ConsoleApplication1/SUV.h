#pragma once
#include "stdafx.h"
#include "Masina.h"

class SUV : public Masina
{
	virtual int getConsum() = 0;
};