#pragma once

#include "stdafx.h"
#include "SUV.h"

class RangeOver : public SUV
{
	int consum;
public:
	void setConsum(int consum_);
	int getConsum();
	string getName();
};