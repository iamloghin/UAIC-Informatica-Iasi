#include "stdafx.h"
#include "Dacia.h"

void Dacia::setCapacitate(int capacitate_)
{
	capacitate = capacitate_;
}

void Dacia::setCuloare(string culoare_)
{
	culoare = culoare_;
}

int Dacia::getCapacitate()
{
	return capacitate;
}

string Dacia::getCuloare()
{
	return culoare;
}

string Dacia::getName()
{
	string nume = "Dacia";
	return nume;
}
