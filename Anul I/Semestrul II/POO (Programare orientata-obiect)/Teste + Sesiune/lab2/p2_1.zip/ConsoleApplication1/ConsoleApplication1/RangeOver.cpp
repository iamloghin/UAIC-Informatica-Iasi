#include "stdafx.h"
#include "RangeOver.h"

void RangeOver::setConsum(int consum_)
{
	consum = consum_;
}

int RangeOver::getConsum()
{
	return consum;
}

string RangeOver::getName()
{
	string nume = "RangeOver";
	return nume;
}
