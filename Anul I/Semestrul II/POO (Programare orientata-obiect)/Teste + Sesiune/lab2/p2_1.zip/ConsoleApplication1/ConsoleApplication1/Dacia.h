#pragma once

#include "stdafx.h"
#include "MasinaOras.h"

class Dacia : public MasinaOras
{
	int capacitate;
	string culoare;
public:
	void setCapacitate(int capacitate_);
	void setCuloare(string culoare_);
	int getCapacitate();
	string getCuloare();
	string getName();
};