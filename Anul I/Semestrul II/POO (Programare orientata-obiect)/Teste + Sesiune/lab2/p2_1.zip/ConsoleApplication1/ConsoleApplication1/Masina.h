#pragma once

#include "stdafx.h"
#include <iostream>
#include <string>

using namespace std;

class Masina
{
public:
	virtual string getName() = 0;
};