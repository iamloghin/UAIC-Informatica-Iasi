#include "stdafx.h"
#include "Opel.h"

void Opel::setCapacitate(int capacitate_)
{
	capacitate = capacitate_;
}

void Opel::setCuloare(string culoare_)
{
	culoare = culoare_;
}

void Opel::setAnFabricatie(int fabricatie_)
{
	anFabricatie = fabricatie_;
}

int Opel::getAnFabricatie()
{
	return anFabricatie;
}

int Opel::getCapacitate()
{
	return capacitate;
}

string Opel::getCuloare()
{
	return culoare;
}

string Opel::getName()
{
	string nume = "Opel";
	return nume;
}
