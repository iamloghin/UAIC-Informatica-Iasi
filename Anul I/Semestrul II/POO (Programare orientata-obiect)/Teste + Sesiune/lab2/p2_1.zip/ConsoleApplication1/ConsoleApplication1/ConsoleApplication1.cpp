// ConsoleApplication1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Masina.h"
#include "MasinaOras.h"
#include "SUV.h"
#include "Dacia.h"
#include "Opel.h"
#include "RangeOver.h"

int main()
{
	Opel o;

	o.setCapacitate(100);
	o.setCuloare("rosu");
	o.setAnFabricatie(2000);

	MasinaOras *m = &o;

	cout << m->getName() << "," << m->getCuloare() << "," << m->getCapacitate() << "," << o.getAnFabricatie() << endl;

	system("PAUSE");
    return 1;
}

