#pragma once
#include <stdio.h>
#include <iostream>

using namespace std;

template <class T>
class Lista
{
private:
    T val;
    Lista *root, *next;
public:

    Lista()
    {
        root = next = NULL;
    }

    bool Add(T elem)
    {
        if (root == NULL) //lista este vida
        {
            root = new Lista<T>();
            if (root == NULL)
            {
                printf("Nu am putut aloca memorie\n");
                return false;
            }

            root->next = NULL;
            root->val = elem;
        }
        else
        {
            Lista<T> *tmp = new Lista<T>();
            if (tmp == NULL)
            {
                printf("Nu am putut aloca memorie\n");
                return false;
            }

            tmp->next = NULL;
            tmp->val = elem;

            Lista<T> *p = root;

            while (p->next != NULL) // ne ducem la ultimul element
                p = p->next;
            p->next = tmp; // adaugam elementul nou la final
        }
        return true;
    }

    bool Insert(T elem, int pos)
    {
        if (pos < 0)
            return false;

        if (pos == 0) // inseamna ca noul element va deveni varful listei
        {
            Lista<T> *tmp = new Lista<T>();
            if (tmp == NULL)
                return false;
            tmp->val = elem;
            tmp->next = root;
            root = tmp;
            return true;
        }

        int idx = 0;
        Lista<T> *p = root;
        while (p->next != NULL && idx < pos - 1)
        {
            p = p->next;
            idx++;
        }

        if (idx == pos - 1) // este posibil ca pos sa fie mai mare decat numarul de elemente din lista
        {
            Lista<T> *tmp = new Lista<T>();
            if (tmp == NULL)
                return false;
            tmp->val = elem;
            tmp->next = p->next;
            p->next = tmp;
        }
        else
        {
            return false;
        }

        return true;

    }

    bool Delete(int pos)
    {
        if (pos < 0)
            return false;
        int idx = 0;
        Lista<T> *p = root;
        Lista<T> *q;

        if (pos == 0)
        {
            q = root;
            root = root->next;
            delete q;
            return true;
        }

        while (p->next != NULL && idx < pos - 1)
        {
            p = p->next;
            idx++;
        }
        if (idx == pos - 1)
        {
            q = p->next;
            p->next = p->next->next;
            delete q;
        }
        else
        {
            return false;
        }

        return true;
    }

    T operator[](int pos)
    {
        if (pos < 0)
            return root->val;

        int idx = 0;
        Lista<T> *p = root;
        while (p != NULL && idx < pos)
        {
            p = p->next;
            idx++;
        }

        if (idx == pos)
            return p->val;
        return 0; //atentie. 0 merge doar in anumite cazuri (tipuri de baza -- int, char, double, pointeri ...). Nu va merge daca la declararea listei folosim obiecte -- Lista<Obiect>. Dar Lista<Obiect*> este ok, deoarece Obiect* este pointer. 

    }

    void afisare()
    {
        Lista<T> *p= root;
        while (p != NULL)
        {
            cout << p->val << '\n';
            p = p->next;
        }
        cout << "================\n";
    }
};
