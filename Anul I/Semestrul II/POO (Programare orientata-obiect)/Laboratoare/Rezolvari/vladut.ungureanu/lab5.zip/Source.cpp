#include "Header.h"


int main()
{

    Lista<char*> *l = new Lista<char*>(); // T va fi inlocuit cu char*

    l->Add("Ana");
    l->Add("are");
    l->Add("mere");
    l->Add("!");

    l->afisare();
    l->Delete(3);
    l->afisare();
    l->Insert("elem2", 0);
    l->afisare();

    cout << (*l)[1] << '\n';

}