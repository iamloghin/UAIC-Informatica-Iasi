#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MATRIX_HEIGHT 6
#define MATRIX_WIDTH 5
int Matrix[MATRIX_HEIGHT][MATRIX_WIDTH];

int dist(int p1_x, int p1_y, int p2_x, int p2_y)
{
    return sqrt(((p1_x - p2_x) * (p1_x - p2_x) + (p1_y - p2_y) * (p1_y - p2_y))) + 0.99;
}

void Circle(int* ptr, int cx, int cy, int ray) 
{
    for(int i=0;i<MATRIX_HEIGHT; i++)
        for (int j = 0;j < MATRIX_WIDTH; j++)
        {
            int d = dist(i, j, cy, cx);
            if (d == ray )
                *(ptr + i * MATRIX_HEIGHT + j) = 1;
        }

    for (int i = 0;i<MATRIX_HEIGHT; i++, printf("\n"))
        for (int j = 0;j < MATRIX_WIDTH; j++)
        {
            printf("%d ", *(ptr + i * MATRIX_HEIGHT + j));
        }


}

int main()
{
    Circle(&Matrix[0][0], 2, 2, 2);


    FILE *f;
    char s[1000];
    int *a;
    int lg = 0, max_lg = 100;

    f = fopen("test.txt", "r");

    a = (int*)malloc(100 * sizeof(int));
    if (!a)
    {
        printf("malloc return NULL\n");
        return 1;
    }

    while (fgets(s, 1000, f))
    {

        int tmp = atoi(s);
        if (lg < max_lg)
            a[lg++] = tmp;
        else
        {
            a = (int*)realloc(a, max_lg * 2 * sizeof(int));
            if (!a)
            {
                printf("Realloc failed\n");
                return 1;
            }

            max_lg *= 2;
            a[lg++] = tmp;
        }

    }

    for (int i = 0;i < lg;i++)
        printf("%d\n", a[i]);


}