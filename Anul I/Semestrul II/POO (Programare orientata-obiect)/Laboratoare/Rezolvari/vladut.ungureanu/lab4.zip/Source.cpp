#include "Forma.h"



int main()
{

    Forma *f[20];

    for (int i = 0;i < 20;i++)
    {
        switch (i % 3)
        {
        case 0:
            f[i] = new Dreptunghi(2, 4);
            break;
        case 1:
            f[i] = new Cerc(5);
            break;
        case 2:
            f[i] = new Triunghi(15, 15, 23, 30, 43, 15);
            break;
        default:
            break;
        }
    }

    for (int i = 0;i < 20;i++)
    {
        printf("Forma: %s\n", f[i]->GetName());
        printf("Aria: %lf\n", f[i]->ComputeArea());
        printf("================\n");
    }

    return 0;
}