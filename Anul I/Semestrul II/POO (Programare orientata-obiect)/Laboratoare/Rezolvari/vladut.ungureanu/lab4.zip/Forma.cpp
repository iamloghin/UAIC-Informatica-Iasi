#include "Forma.h"


// ============== DREPTUNGHI ==============

Dreptunghi::Dreptunghi(int lungime, int latime)
{
    Lungime = lungime;
    Latime = latime;
}

double Dreptunghi::ComputeArea()
{
    return Lungime * Latime;
}

const char* Dreptunghi::GetName()
{
    return "Dreptunghi";
}

// ============== CERC ==============

Cerc::Cerc(int raza)
{
    Raza = raza;
}

double Cerc::ComputeArea()
{
    return PI * (Raza * Raza);
}

const char* Cerc::GetName()
{
    return "Cerc";
}

// ============== TRIUNGHI ==============

int distanta(int x1, int y1, int x2, int y2)
{
    return sqrt((x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2));
}

Triunghi::Triunghi(int x1, int y1, int x2, int y2, int x3, int y3)
{
    X1 = x1;
    X2 = x2;
    X3 = x3;
    
    Y1 = y1;
    Y2 = y2;
    Y3 = y3;
}

double Triunghi::ComputeArea()
{
    double a = distanta(X1, Y1, X2, Y2);
    double b = distanta(X1, Y1, X3, Y3);
    double c = distanta(X2, Y2, X3, Y3);

    double p = (a + b + c) / 2;

    return sqrt(p * (p - a)*(p - b)*(p - c));
}

const char* Triunghi::GetName()
{
    return "Triunghi";
}