#include "InList.h"

IntList::IntList()
{
    Count = 0;
}

bool IntList::Add(int element)
{
    if (Count == 1000)
        return false;

    Elemente[Count++] = element;
    return true;
}

bool IntList::Insert(int index, int element)
{
    if (Count == 1000 || index > Count || index < 0)
        return false;

    memcpy(Elemente + index + 1, Elemente + index, (Count - index) * sizeof(int));
    Elemente[index] = element;
    Count++;

    return true;

    /*
    http://www.cplusplus.com/reference/cstring/memcpy/
    memcpy este folosit pentru a copia un buffer in alt buffer
    memcpy(destinatie, sursa, dimensiune in bytes) -- bytes calculat ca la malloc (cu * sizeof(tip))

    alternativa fara memcpy
    
    for(int i=Count;i>index;i--)
        Elemente[i] = Elemente[i-1];
    Elemente[index] = element;
    Count++;

    */

}

bool IntList::Delete(int index)
{
    if (index >= 1000 || index < 0 || index > Count)
        return false;

    memcpy(Elemente + index, Elemente + index + 1, (Count - index) * sizeof(int));
    Count--;

    return true;

    /*
    alternativa fara memcpy

    for(int i=index;i<Count-1;i++)
        Elemente[i] = Elemente[i+1]
    Count--;
    */
}

void IntList::Clear()
{
    memset(Elemente, 0, 1000 * sizeof(int));
    Count = 0;

    /*
    memset seteaza elemente din buffer cu o anumita valoare

    memset(buffer, valoare, dimensiune) -- dimensiunea este in bytes
    */
}

int  IntList::IndexOf(int valoare, int startPosition)
{
    if (startPosition < 0 || startPosition > Count)
        return -1;

    for (int i = startPosition;i < Count;i++)
        if (Elemente[i] == valoare)
            return i;
    return -1;
}

void IntList::RemoveDuplicates()
{
    for (int i = 0;i < Count; i++)
    {
        for (int j = i + 1;j < Count;j++)
        {
            if (Elemente[i] == Elemente[j])
            {
                Delete(j);
                j--;
            }
        }
    }
}

void IntList::Intersection(IntList* withList, IntList * resultList)
{
    for (int i = 0;i < Count;i++)
        for (int j = 0;j < withList->Count;j++)
            if (Elemente[i] == withList->Elemente[j])
                resultList->Add(Elemente[i]);
    resultList->RemoveDuplicates();
}

void IntList::Reunion(IntList* withList, IntList * resultList)
{
    for (int i = 0;i < Count;i++)
        resultList->Add(Elemente[i]);
    for (int i = 0;i < withList->Count;i++)
        resultList->Add(withList->Elemente[i]);
    resultList->RemoveDuplicates();
}

void IntList::Sort()
{
    bool sch;
    do
    {
        sch = false;
        for(int i=0;i<Count - 1;i++)
            if (Elemente[i] > Elemente[i + 1])
            {
                int tmp = Elemente[i];
                Elemente[i] = Elemente[i + 1];
                Elemente[i + 1] = tmp;
                sch = true;
            }
    } while (sch == true);
}

void IntList::Reverse()
{
    int tmp, i;
    for (i = 0;i < Count / 2;i++)
    {
        tmp = Elemente[i];
        Elemente[i] = Elemente[Count - i - 1];
        Elemente[Count - i - 1] = tmp;
        
    }
}
int  IntList::Get(int index)
{
    if (index > Count || index < 0)
        return -1;
    return Elemente[index];
}
int  IntList::GetCount()
{
    return Count;
}

void IntList::print()
{
    for (int i = 0;i < Count;i++)
        printf("%d ", Elemente[i]);
    printf("\n");
}