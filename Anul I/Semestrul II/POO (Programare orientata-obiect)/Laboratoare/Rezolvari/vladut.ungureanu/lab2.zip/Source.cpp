#include <stdio.h>
#include "InList.h"


int main()
{

    IntList *A = new IntList();
    IntList *B = new IntList();
    IntList *C = new IntList();
    IntList *D = new IntList();

    A->Add(2);
    A->Add(23);
    A->Add(0);
    A->Add(-1);
    A->Add(2123);
    A->Add(5);

    printf("A: ");
    A->print();

    A->Insert(2, 11);
    printf("A after insert: ");
    A->print();

    A->Delete(4);
    printf("A after delete: ");
    A->print();

    printf("Index of: %d\n", A->IndexOf(2123, 2));

    A->Add(7);
    A->Add(7);
    A->Add(7);
    A->Add(-2);
    printf("A aftre remove duplicate: ");
    A->RemoveDuplicates();
    A->print();

    B->Add(23);
    B->Add(0);
    B->Add(111);
    B->Add(232);

    printf("B: ");
    B->print();

    printf("intersectie: ");
    A->Intersection(B, C);
    C->print();

    printf("reuniune: ");
    A->Reunion(B, D);
    D->print();

    printf("sort A: ");
    A->Sort();
    A->print();

    printf("rever A after sort: ");
    A->Reverse();
    A->print();

    return 0;
}