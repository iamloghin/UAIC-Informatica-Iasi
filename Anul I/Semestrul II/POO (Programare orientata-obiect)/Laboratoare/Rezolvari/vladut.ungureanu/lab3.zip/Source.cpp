#include "BigNumber.h"



int main()
{
    BigNumber A, B, C, D, E, F;
    BigNumber sum, dif, prod, div;

    A.Set(1234);
    B.Set("1234");

    C.Set(31234);
    D.Set(1234);

    E.Set(1234);
    F.Set(9111);

    printf("A: ");
    A.print();
    printf("B: ");
    B.print();
    printf("C: ");
    C.print();
    printf("D: ");
    D.print();
    printf("E: ");
    E.print();
    printf("F: ");
    F.print();

    printf("A == B (%d)\n", A == B);
    printf("A < B (%d)\n", A < B);
    printf("A > B (%d)\n", A > B);
    printf("C >= D (%d)\n", C >= D);
    printf("E > F (%d)\n", E > F);

    sum = E + F;
    printf("E + F: ");
    sum.print();

    dif = F - E;
    printf("F - E: ");
    dif.print();


    prod = A * C;
    printf("A * C: ");
    prod.print();

    div= C / F;
    printf("C / F: ");
    div.print();

    printf("operator int: %d\n", (int)D);
    printf("operator [2]: %d\n", D[2]);
    F = C(1, 4);
    printf("operator (1, 4): ");
    F.print();


    return 0;
}