#include "BigNumber.h"

BigNumber::BigNumber()
{
    memset(Number, NULL, 256); // pun 0(NULL) peste tot
    Number[0] = '0'; // 0 nu este acelasi lucru cu '0'.
    CharactersCount = 1;
}

BigNumber::BigNumber(int value)
{
    memset(Number, NULL, 256);
    Set(value);
}

BigNumber::BigNumber(const char * number)
{
    memset(Number, NULL, 256);
    Set(number);
}

BigNumber::BigNumber(const BigNumber & number)
{
    memset(Number, NULL, 256);
    CharactersCount = number.CharactersCount;

    memcpy(Number, number.Number, CharactersCount * sizeof(char)); // sizeof(char) = 1. De obicei, in astfel de cazuri nu se mai scrie * sizeof(char)
}

bool BigNumber::Set(int value)
{
    CharactersCount = 0;
    if (value == 0)
        Number[CharactersCount++] = '0';
    while (value)
    {
        Number[CharactersCount++] = (value % 10) + '0';
        value /= 10;
    }

    return true;
}

bool BigNumber::Set(const char * number)
{
    CharactersCount = 0;
    if (strlen(number) > 256)
        return false;

    for (int i = strlen(number) - 1; i >= 0; i--)
        Number[CharactersCount++] = number[i];

    return true;
}

/*
    return conditie ? val1 : val2;
    echivalent

    if(conditie) retunr val1;
    else return val2;
    http://www.cplusplus.com/reference/cstring/memcmp/

*/

bool operator == (const BigNumber & n1, const BigNumber & n2)
{
    if (n1.CharactersCount != n2.CharactersCount)
        return false;
    return memcmp(n1.Number, n2.Number, n1.CharactersCount) ? false : true;
}

bool operator != (const BigNumber & n1, const BigNumber & n2)
{
    if (n1.CharactersCount != n2.CharactersCount)
        return true;
    return memcmp(n1.Number, n2.Number, n1.CharactersCount) ? true : false;
}

bool operator <  (const BigNumber & n1, const BigNumber & n2)
{
    if (n1.CharactersCount < n2.CharactersCount)
        return true;
    if (n1.CharactersCount > n2.CharactersCount)
        return false;

    int i = n1.CharactersCount - 1;
    while (i && n1.Number[i] == n2.Number[i])
        i--;
    
    return n1.Number[i] < n2.Number[i];

}

bool operator >  (const BigNumber & n1, const BigNumber & n2)
{
    if (n1.CharactersCount > n2.CharactersCount)
        return true;
    if (n1.CharactersCount < n2.CharactersCount)
        return false;

    int i = n1.CharactersCount - 1;
    while (i && n1.Number[i] == n2.Number[i])
        i--;

    return n1.Number[i] > n2.Number[i];
}

bool operator >= (const BigNumber & n1, const BigNumber & n2)
{
    if (n1.CharactersCount > n2.CharactersCount)
        return true;
    if (n1.CharactersCount < n2.CharactersCount)
        return false;

    int i = n1.CharactersCount - 1;
    while (i && n1.Number[i] == n2.Number[i])
        i--;

    return n1.Number[i] >= n2.Number[i];
}

bool operator <= (const BigNumber & n1, const BigNumber & n2)
{
    if (n1.CharactersCount < n2.CharactersCount)
        return true;
    if (n1.CharactersCount > n2.CharactersCount)
        return false;

    int i = n1.CharactersCount - 1;
    while (i && n1.Number[i] == n2.Number[i])
        i--;

    return n1.Number[i] <= n2.Number[i];
}

/*

    La adunare/scadere
    - pentru a putea lucra cu numere si nu caractere se scade '0' din Number[i]
    - cele 2 numere pot avea dimensiune diferita
    - deoarece in 'for' se foloseste || , putem sa ajungem cu un indice (i sau j) > CharactersCount. 
    - vectorul Number a fost initializat cu NULL peste tot, deci daca intalnim NULL inseamna ca trebuie ignorat
*/

BigNumber BigNumber::operator+ (const BigNumber & number)
{
    int i, j, t;
    int nr1, nr2, tmp;
    BigNumber res; // se apeleaza constructorul implicit

    t = 0;
    res.CharactersCount = 0;
    for (i = 0, j = 0;i < CharactersCount || j < number.CharactersCount || t; i++, j++)
    {
        nr1 = nr2 = 0;

        if (Number[i])
            nr1 = Number[i] - '0';
        if (number.Number[j])
            nr2 = number.Number[j] - '0';

        tmp = nr1 + nr2 + t;
        
        res.Number[res.CharactersCount++] = (tmp % 10) + '0';
        t = tmp / 10;
    }

    return res;

}

BigNumber BigNumber::operator- (const BigNumber & number)
{
    int i, t, nr1, nr2;
    BigNumber res; // se apeleaza constructorul implicit

    t = 0;
    res.CharactersCount = 0;
    for (i = 0;i < CharactersCount;i++)
    {
        nr1 = nr2 = 0;
        if (Number[i] != NULL)
            nr1 = Number[i] - '0';
        if (number.Number[i] != NULL)
            nr2 = number.Number[i] - '0';
        res.Number[res.CharactersCount] = nr1 - nr2 + t;
        if (res.Number[res.CharactersCount] < 0)
        {
            res.Number[res.CharactersCount] += 10;
            t = -1;
        }
        else t = 0;
        res.Number[res.CharactersCount] = res.Number[res.CharactersCount] + '0';
        res.CharactersCount++;
    }

    i--;
    while (i && res.Number[i] == '0')
        i--;
    res.CharactersCount = i + 1;
    return res;
}



BigNumber BigNumber::operator* (const BigNumber & number)
{
    BigNumber res(*this); // se apeleaza constructorul explicit
    BigNumber idx(1); // se apeleaza constructorul explicit
    BigNumber unu(1);

    while (idx < (*this))
    {
        res = res + number;
        idx = idx + unu;
    }
    return res;
}


BigNumber BigNumber::operator/ (const BigNumber & number)
{
    BigNumber res(*this); // se apeleaza constructorul explicit
    BigNumber cat;
    BigNumber unu(1); // se apeleaza constructorul explicit
    BigNumber zero;

    while (res > number)
    {
        res = res - number;
        cat = cat + unu;
    }
    return cat;
}

BigNumber::operator int()
{
    int res = 0;
    for (int i = CharactersCount - 1;i >= 0;i--)
    {
        res = res * 10 + (Number[i] - '0');
    }
    return res;
}

char BigNumber::operator[](int index)
{
    if (index <0 || index > CharactersCount)
        return 0;

    return Number[CharactersCount - index - 1] - '0';
}

BigNumber BigNumber::operator()(int start, int end)
{
    BigNumber res;

    if (start < 0 || start > CharactersCount || end < 0 || end > CharactersCount || start > end)
    {
        res.Set(0);
        return res;
    }

    char tmp[256] = { 0 };
    memcpy(tmp, Number + start, end - start);
    res.Set(tmp);

    return res;
}

void BigNumber::print()
{
    for (int i = CharactersCount - 1;i >= 0;i--)
        printf("%c", Number[i]);
    printf("\n");
}